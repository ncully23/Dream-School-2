// /assets/js/pages/quizpage.js
// Bootstraps a quiz by:
// 1) Reading ?quizId=...
// 2) Loading /assets/configs/quizzes.json
// 3) Fetching the referenced question bank JSON
// 4) Selecting N questions (currently: first N, deterministic)
// 5) Setting window.dsaQuizConfig (with questions[]) then importing quiz-engine.js
//
// IMPORTANT PRODUCT DECISION (per your requirement):
// - Students may navigate and change answers while taking the quiz.
// - If they refresh/leave before submitting, NOTHING is saved and the quiz restarts.
//   We make this explicit via an on-page warning + a browser "leave page" prompt.

import { routes } from "/assets/js/lib/routes.js";

function qs(name) {
  try { return new URLSearchParams(location.search).get(name); } catch { return null; }
}

async function loadJson(url) {
  const res = await fetch(url, { cache: "no-store", headers: { Accept: "application/json" } });
  if (!res.ok) throw new Error(`Failed to fetch ${url}: HTTP ${res.status}`);
  return res.json();
}

function injectBanner(message, tone = "warn") {
  // tone: "warn" | "info"
  const existing = document.getElementById("dsa-ephemeral-banner");
  if (existing) existing.remove();

  const box = document.createElement("div");
  box.id = "dsa-ephemeral-banner";
  box.setAttribute("role", "status");
  box.style.cssText = [
    "max-width:980px",
    "margin:10px auto 0",
    "padding:10px 12px",
    "border-radius:12px",
    "border:1px solid #cfd7ea",
    "box-shadow:0 6px 14px rgba(16,24,40,.08)",
    "font:14px/1.4 Inter,system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial",
    "background:" + (tone === "info" ? "#f1f5ff" : "#fff7ed"),
    "color:#0f172a"
  ].join(";");

  box.innerHTML = message;

  // Place it right under the sticky header (after .header) if present, otherwise top of .app
  const header = document.querySelector(".header");
  if (header && header.parentElement) header.insertAdjacentElement("afterend", box);
  else document.body.prepend(box);
}

function normalizeQuizConfig(rawCfg, quizId) {
  const cfg = rawCfg || {};
  return {
    quizId: cfg.quizId || quizId,
    sectionId: cfg.sectionId || cfg.quizId || quizId,

    // UI
    title: cfg.sectionTitle || cfg.title || "Quiz",
    sectionTitle: cfg.sectionTitle || cfg.title || "Quiz",

    // behavior
    mode: cfg.mode || "practice",
    timeLimitSec: Number(cfg.timeLimitSec) || 0,
    questionCount: Number(cfg.questionCount) || Number(cfg.count) || 10,

    // bank
    bankUrl: cfg.bank || cfg.bankUrl || null,

    // optional metadata
    difficulty: cfg.difficulty || null,
    skills: Array.isArray(cfg.skills) ? cfg.skills : null,
    studyHref: cfg.studyHref || null,
    previewDescription: cfg.previewDescription || null
  };
}

function pickQuestions(bankQuestions, n) {
  const list = Array.isArray(bankQuestions) ? bankQuestions : [];
  const count = Math.max(0, Math.min(Number(n) || 0, list.length));
  // Deterministic for now (first N). Later you can switch to seeded random.
  return list.slice(0, count);
}

function setPageTitle(title) {
  const titleEl = document.getElementById("sectionTitle");
  if (titleEl) titleEl.textContent = title || "Quiz";

  const checkTitleEl = document.getElementById("checkTitle");
  if (checkTitleEl) checkTitleEl.textContent = title ? `${title} Questions` : "Questions";

  const popTitleEl = document.getElementById("popTitle");
  if (popTitleEl) popTitleEl.textContent = title ? `${title} Questions` : "Questions";

  document.title = title || "Quiz";
}

function setPracticeBannerVisible(show) {
  const practiceBanner = document.getElementById("practiceBanner");
  if (practiceBanner) practiceBanner.style.display = show ? "flex" : "none";
}

function getEphemeralFlagKey(quizId) {
  return `dsa:ephemeral-inprogress:${quizId}`;
}

function markQuizInProgress(quizId) {
  try { sessionStorage.setItem(getEphemeralFlagKey(quizId), "1"); } catch {}
}

function clearQuizInProgress(quizId) {
  try { sessionStorage.removeItem(getEphemeralFlagKey(quizId)); } catch {}
}

function wasQuizInProgress(quizId) {
  try { return sessionStorage.getItem(getEphemeralFlagKey(quizId)) === "1"; } catch { return false; }
}

async function main() {
  const quizId = qs("quizId");
  if (!quizId) {
    console.warn("quizpage: missing ?quizId=... redirecting to practice hub");
    location.href = (routes && routes.practice) ? routes.practice() : "/practice/index.html";
    return;
  }

  // Load quiz configs
  const all = await loadJson("/assets/configs/quizzes.json");
  const cfgRaw = all && all[quizId] ? all[quizId] : null;

  if (!cfgRaw) {
    console.warn("quizpage: unknown quizId:", quizId);
    location.href = (routes && routes.practice) ? routes.practice() : "/practice/index.html";
    return;
  }

  const cfg = normalizeQuizConfig(cfgRaw, quizId);
  setPageTitle(cfg.title);
  setPracticeBannerVisible(cfg.mode !== "exam");

  // Ephemeral attempt behavior banner(s)
  // 1) Always show: "progress not saved"
  injectBanner(
    `<b>Heads up:</b> Your progress is <b>not saved</b> until you click <b>End &amp; Score</b>. ` +
    `If you refresh or leave this page, this attempt is discarded and you’ll restart from Question 1.`,
    "warn"
  );

  // 2) If they *already* had an in-progress attempt (refresh/back), call it out explicitly.
  if (wasQuizInProgress(quizId)) {
    injectBanner(
      `<b>Previous attempt discarded.</b> You left or refreshed before submitting, so we restarted this quiz from the beginning.`,
      "info"
    );
  }

  // Mark attempt in progress (session-only)
  markQuizInProgress(quizId);

  // Leave-page prompt (makes the behavior explicit)
  window.addEventListener("beforeunload", (e) => {
    // If the engine marks finished, it will clear this flag (see below).
    if (wasQuizInProgress(quizId)) {
      e.preventDefault();
      // Chrome requires returnValue to be set
      e.returnValue = "";
      return "";
    }
  });

  // Load bank + select questions
  if (!cfg.bankUrl) {
    throw new Error(`Quiz config for "${quizId}" is missing a 'bank' URL.`);
  }

  const bank = await loadJson(cfg.bankUrl);
  const picked = pickQuestions(bank.questions, cfg.questionCount);

  if (!picked.length) {
    throw new Error(`Question bank loaded, but no questions were selected (bank: ${cfg.bankUrl}).`);
  }

  // Expose a fully-resolved config WITH questions for quiz-engine.js to run immediately.
  window.dsaQuizConfig = {
    quizId: cfg.quizId,
    sectionId: cfg.sectionId,
    title: cfg.title,
    sectionTitle: cfg.sectionTitle,

    timeLimitSec: cfg.timeLimitSec,

    // Bank metadata (used by review + analytics)
    bankId: bank.bankId || cfg.quizId,
    bankVersion: bank.bankVersion || null,
    bankTitle: bank.title || cfg.title || null,
    bankDescription: bank.description || null,
    bankSkills: Array.isArray(bank.skills) ? bank.skills : (cfg.skills || null),

    // Questions
    questions: picked
  };

  // Ensure firebase quizData API is available (engine will use it if signed-in)
  await import("/assets/js/quiz-data.js");

  // When the attempt is successfully finished, quiz-engine will redirect.
  // We also clear the in-progress flag when the tab is hidden AND the next page loads.
  // (This is conservative: the flag mainly exists to show the "discarded" banner on reload.)
  window.addEventListener("pagehide", () => {
    // If they navigate away without finishing, we keep it set so the next load can show "discarded".
    // If they finish, review.html load can clear it; see reviewpage.js.
  });

  // Start the engine
  await import("/assets/js/quiz-engine.js");
}

// Go
main().catch((err) => {
  console.error("quizpage: failed to boot quiz", err);
  const msg = (err && err.message) ? err.message : String(err);
  const box = document.createElement("div");
  box.style.cssText =
    "max-width:980px;margin:14px auto;padding:12px 14px;background:#fff;border:1px solid #c00;border-radius:10px;" +
    "font:16px/1.45 system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial;color:#111;";
  box.innerHTML = `<h2 style="margin:0 0 6px;font-size:18px">Quiz failed to load</h2><p style="margin:0">${msg}</p>`;
  (document.body || document.documentElement).prepend(box);
});
