// /assets/js/quiz-data.js
// Central Firebase + quiz persistence layer (modular SDK).
//
// - Does NOT define window.examConfig (each quiz page must do that).
// - Exposes window.quizData with helpers used by:
//   * quiz-engine.js  → appendAttempt(), saveSessionProgress(), etc.
//   * progress.js     → loadAllResultsForUser()
//   * legacy pages    → recordTestResult(), exportAttempts()
//
// IMPORTANT:
// - Uses modular Firebase via firebase-init.js (shared with shell.js).
// - Do NOT include firebase-app-compat/auth-compat/firestore-compat in HTML.
// - Instead, load this file as a module AFTER firebase-init.js and shell.js.

import { auth, db } from "./firebase-init.js";

import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  writeBatch,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/10.12.4/firebase-firestore.js";

import {
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/10.12.4/firebase-auth.js";

const DEBUG = false;
function dbg(...args) {
  if (DEBUG) console.log("[quiz-data]", ...args);
}

// -----------------------------------
// 2. Local recorder-style store (backup only)
// -----------------------------------
const LOCAL_ATTEMPT_KEY = "dreamschool:attempts:v1";

function loadLocalAttempts() {
  try {
    const raw = localStorage.getItem(LOCAL_ATTEMPT_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (e) {
    console.warn("quiz-data: failed to load local attempts", e);
    return [];
  }
}

function saveLocalAttempts(list) {
  try {
    localStorage.setItem(LOCAL_ATTEMPT_KEY, JSON.stringify(list));
  } catch (e) {
    console.warn("quiz-data: failed to save local attempts", e);
  }
}

function clearLocalAttempts() {
  try {
    localStorage.removeItem(LOCAL_ATTEMPT_KEY);
  } catch (e) {
    console.warn("quiz-data: failed to clear local attempts", e);
  }
}

function createAttemptId() {
  return "t_" + Date.now() + "_" + Math.floor(Math.random() * 10000);
}

// Build a compact local record from a normalized summary
function buildCoreRecordFromSummary(normalized, attemptId) {
  const totals = normalized.totals || {};
  const score = typeof totals.correct === "number" ? totals.correct : 0;
  const total = typeof totals.total === "number" ? totals.total : 0;

  const scorePercent =
    typeof totals.scorePercent === "number"
      ? totals.scorePercent
      : total > 0
      ? Math.round((score / total) * 100)
      : 0;

  const durationSeconds =
    typeof totals.timeSpentSec === "number" ? totals.timeSpentSec : 0;

  const timestamp = normalized.generatedAt || new Date().toISOString();
  const sectionId = normalized.sectionId || null;
  const title = normalized.title || null;

  const answers = Array.isArray(normalized.items)
    ? normalized.items.map((item) => ({
        number: item.number || null,
        id: item.id || null,
        chosenIndex:
          typeof item.chosenIndex === "number" ? item.chosenIndex : null,
        correctIndex:
          typeof item.correctIndex === "number" ? item.correctIndex : null,
        correct: !!item.correct
      }))
    : [];

  return {
    id: attemptId,
    sectionId,
    title,
    timestamp,
    score,
    total,
    scorePercent,
    durationSeconds,
    answers
  };
}

// Upsert core record into local store, marking synced true/false
function upsertLocalAttemptFromSummary(normalized, options) {
  const attemptId =
    normalized.attemptId || normalized.id || createAttemptId();

  normalized.attemptId = attemptId;

  const core = buildCoreRecordFromSummary(normalized, attemptId);
  const synced = !!(options && options.synced);

  const list = loadLocalAttempts();
  const idx = list.findIndex((r) => r.id === attemptId);

  const record = {
    ...(idx >= 0 ? list[idx] : {}),
    ...core,
    synced
  };

  if (idx >= 0) {
    list[idx] = record;
  } else {
    list.push(record);
  }

  saveLocalAttempts(list);
  return record;
}

// -----------------------------------
// 3. examConfig helpers
// -----------------------------------
function getExamConfig() {
  return typeof window !== "undefined" && window.examConfig
    ? window.examConfig
    : {};
}

function getDefaultSectionId() {
  const exam = getExamConfig();
  if (exam && typeof exam.sectionId === "string" && exam.sectionId.trim()) {
    return exam.sectionId.trim();
  }
  return null;
}

function getDefaultTitle() {
  const exam = getExamConfig();
  if (exam && typeof exam.sectionTitle === "string" && exam.sectionTitle.trim()) {
    return exam.sectionTitle;
  }
  return null;
}

// -----------------------------------
// 4. Auth helpers (modular)
// -----------------------------------
async function requireUser() {
  const current = auth.currentUser;
  if (current) return current;

  return new Promise((resolve, reject) => {
    const unsub = onAuthStateChanged(auth, (user) => {
      unsub();
      if (user) resolve(user);
      else reject(new Error("Not signed in"));
    });
  });
}

function waitForAuthReady() {
  return new Promise((resolve) => {
    const existing = auth.currentUser;
    if (existing) {
      resolve(existing);
      return;
    }
    const unsub = onAuthStateChanged(auth, (user) => {
      unsub();
      resolve(user || null);
    });
  });
}

// -----------------------------------
// 5. Scoring / summary normalization
// -----------------------------------
function computeTotalsFromItems(items) {
  if (!Array.isArray(items) || items.length === 0) {
    return {
      answered: 0,
      correct: 0,
      total: 0,
      timeSpentSec: 0,
      scorePercent: 0
    };
  }

  let answered = 0;
  let correct = 0;
  const total = items.length;
  let timeSpentSec = 0;

  items.forEach((item) => {
    const hasAnswer =
      item.chosenIndex !== null &&
      item.chosenIndex !== undefined &&
      item.chosenIndex !== "";

    if (hasAnswer) answered += 1;

    let isCorrect = false;
    if (typeof item.correct === "boolean") {
      isCorrect = item.correct;
    } else if (
      typeof item.correctIndex === "number" &&
      typeof item.chosenIndex === "number"
    ) {
      isCorrect = item.chosenIndex === item.correctIndex;
    }
    if (isCorrect) correct += 1;

    if (typeof item.timeSpentSec === "number") {
      timeSpentSec += item.timeSpentSec;
    }
  });

  const scorePercent =
    total > 0 ? Math.round((correct / total) * 100) : 0;

  return { answered, correct, total, timeSpentSec, scorePercent };
}

function normalizeAttemptSummary(summary) {
  const safe = summary || {};
  const defaultSectionId = getDefaultSectionId();
  const defaultTitle = getDefaultTitle();

  const sectionId = safe.sectionId || defaultSectionId || null;
  const title = safe.title || defaultTitle || null;
  const items = Array.isArray(safe.items) ? safe.items : [];

  let totals = safe.totals || {};
  if (
    typeof totals.answered !== "number" ||
    typeof totals.correct !== "number" ||
    typeof totals.total !== "number"
  ) {
    totals = computeTotalsFromItems(items);
  } else {
    const computed = computeTotalsFromItems(items);
    if (typeof totals.timeSpentSec !== "number") {
      totals.timeSpentSec = computed.timeSpentSec;
    }
    if (typeof totals.scorePercent !== "number") {
      totals.scorePercent = computed.scorePercent;
    }
  }

  const uiState = {
    timerHidden:
      typeof safe.timerHidden === "boolean"
        ? safe.timerHidden
        : !!(safe.uiState && safe.uiState.timerHidden),
    reviewMode:
      typeof safe.reviewMode === "boolean"
        ? safe.reviewMode
        : !!(safe.uiState && safe.uiState.reviewMode),
    lastQuestionIndex:
      typeof safe.lastQuestionIndex === "number"
        ? safe.lastQuestionIndex
        : (safe.uiState && safe.uiState.lastQuestionIndex) ?? null
  };

  return {
    ...safe,
    sectionId,
    title,
    items,
    totals,
    uiState
  };
}

// -----------------------------------
// 6. Firestore – completed attempts
// -----------------------------------
// Collection path: users/{uid}/examAttempts/{autoId}
async function appendAttempt(summary) {
  const normalized = normalizeAttemptSummary(summary);

  // Local backup (for export/offline tools only)
  const localRecord = upsertLocalAttemptFromSummary(normalized, { synced: false });

  const attemptId = localRecord.id;
  normalized.attemptId = attemptId;

  const sectionId = normalized.sectionId || getDefaultSectionId();
  const title = normalized.title || getDefaultTitle();

  if (!sectionId) {
    console.warn(
      "quiz-data.appendAttempt: No sectionId found. " +
        "Set summary.sectionId or window.examConfig.sectionId."
    );
  }

  const timestamp = localRecord.timestamp;
  const scorePercent = localRecord.scorePercent;
  const durationSeconds = localRecord.durationSeconds;

  let user;
  try {
    user = await requireUser();
  } catch (e) {
    console.warn("quiz-data.appendAttempt: no user signed in, keeping local only.", e);
    return { attemptId, synced: false, localOnly: true };
  }

  try {
    const payload = {
      ...normalized,
      attemptId,
      sectionId: sectionId || null,
      title: title || null,
      userId: user.uid,
      timestamp,
      scorePercent,
      durationSeconds,
      createdAt: serverTimestamp()
    };

    // Canonical storage (Step 6 keying): users/{uid}/attempts/{attemptId}
    const ref = doc(db, "users", user.uid, "attempts", attemptId);
    await setDoc(ref, payload, { merge: true });

    // Optional compatibility mirror (older builds used users/{uid}/examAttempts/{autoId})
    // If you don't want duplication, you can delete this block later.
    try {
      const legacyAttemptsCol = collection(db, "users", user.uid, "examAttempts");
      const legacyRef = doc(legacyAttemptsCol);
      await setDoc(legacyRef, payload);
    } catch (e) {
      // Non-fatal
      dbg("legacy mirror write failed", e);
    }

    // Mark local copy synced
    upsertLocalAttemptFromSummary(normalized, { synced: true });

    return { attemptId, synced: true, docId: attemptId };
  } catch (e) {
    console.warn(
      "quiz-data.appendAttempt: Firestore write failed, local record kept as synced:false",
      e
    );
    return {
      attemptId,
      synced: false,
      error: e && e.message ? e.message : String(e)
    };
  }
}

// -------- Tutor/Admin helpers --------

async function getCurrentUserRole() {
  const user = await waitForAuthReady();
  if (!user) return "anonymous";
  try {
    const ref = doc(db, "users", user.uid);
    const snap = await getDoc(ref);
    const role = snap.exists() ? snap.data()?.role : null;
    if (role === "admin" || role === "tutor" || role === "student") return role;
    return "student";
  } catch {
    return "student";
  }
}

async function canReadOtherUsersData() {
  const role = await getCurrentUserRole();
  return role === "admin" || role === "tutor";
}

async function getAttempt(attemptId, options) {
  if (!attemptId) throw new Error("getAttempt: missing attemptId");
  const current = await waitForAuthReady();
  const requestedUserId = options?.userId || null;

  let userId = current?.uid || null;

  if (requestedUserId && requestedUserId !== userId) {
    const allowed = await canReadOtherUsersData();
    if (!allowed) throw new Error("Not authorized to read other users' attempts.");
    userId = requestedUserId;
  }

  if (!userId) throw new Error("Not signed in");

  // Canonical path
  const ref = doc(db, "users", userId, "attempts", String(attemptId));
  const snap = await getDoc(ref);
  if (snap.exists()) return { id: snap.id, ...snap.data() };

  // Compatibility fallback: look in legacy examAttempts by attemptId field
  const legacyCol = collection(db, "users", userId, "examAttempts");
  const q = query(legacyCol, where("attemptId", "==", String(attemptId)), limit(1));
  const legacySnap = await getDocs(q);
  if (!legacySnap.empty) {
    const d = legacySnap.docs[0];
    return { id: d.id, ...d.data() };
  }

  return null;
}

async function listAttempts(options) {
  const current = await requireUser();
  const requestedUserId = options?.userId || null;

  let userId = current?.uid || null;

  if (requestedUserId && requestedUserId !== userId) {
    const allowed = await canReadOtherUsersData();
    if (!allowed) throw new Error("Not authorized to read other users' attempts.");
    userId = requestedUserId;
  }

  const attempts = [];

  // Canonical
  try {
    const attemptsCol = collection(db, "users", userId, "attempts");
    const q1 = query(attemptsCol, orderBy("createdAt", "desc"));
    const snap1 = await getDocs(q1);
    snap1.forEach((d) => attempts.push({ id: d.id, ...d.data() }));
    if (attempts.length) return attempts;
  } catch (e) {
    dbg("listAttempts canonical failed", e);
  }

  // Legacy fallback
  try {
    const legacyCol = collection(db, "users", userId, "examAttempts");
    const q2 = query(legacyCol, orderBy("createdAt", "desc"));
    const snap2 = await getDocs(q2);
    snap2.forEach((d) => attempts.push({ id: d.id, ...d.data() }));
  } catch (e) {
    dbg("listAttempts legacy failed", e);
  }

  return attempts;
}


async function loadResultsForSection(sectionId) {
  const user = await requireUser();
  const effectiveSectionId = sectionId || getDefaultSectionId();

  if (!effectiveSectionId) {
    throw new Error(
      "quiz-data.loadResultsForSection: No sectionId provided and none found in examConfig."
    );
  }

  // Canonical collection
  try {
    const attemptsCol = collection(db, "users", user.uid, "attempts");
    const q1 = query(
      attemptsCol,
      where("sectionId", "==", effectiveSectionId),
      orderBy("createdAt", "desc")
    );
    const snap1 = await getDocs(q1);
    if (!snap1.empty) return snap1.docs.map((d) => ({ id: d.id, ...d.data() }));
  } catch (e) {
    dbg("loadResultsForSection canonical failed", e);
  }

  // Legacy fallback
  const legacyCol = collection(db, "users", user.uid, "examAttempts");
  const q2 = query(
    legacyCol,
    where("sectionId", "==", effectiveSectionId),
    orderBy("createdAt", "desc")
  );
  const snap2 = await getDocs(q2);
  return snap2.docs.map((d) => ({ id: d.id, ...d.data() }));
}

// Used by progress.js
async function loadAllResultsForUser() {
  const user = await requireUser();

  // Canonical collection
  try {
    const attemptsCol = collection(db, "users", user.uid, "attempts");
    const q1 = query(attemptsCol, orderBy("createdAt", "desc"));
    const snap1 = await getDocs(q1);
    if (!snap1.empty) return snap1.docs.map((d) => ({ id: d.id, ...d.data() }));
  } catch (e) {
    dbg("loadAllResultsForUser canonical failed", e);
  }

  // Legacy fallback
  const legacyCol = collection(db, "users", user.uid, "examAttempts");
  const q2 = query(legacyCol, orderBy("createdAt", "desc"));
  const snap2 = await getDocs(q2);
  return snap2.docs.map((d) => ({ id: d.id, ...d.data() }));
}

// -----------------------------------
// 7. Firestore – in-progress sessions
// -----------------------------------
// Collection path: users/{uid}/examSessions/{sectionId}
async function saveSessionProgress(progressState) {
  if (!progressState) return;

  const user = await requireUser();
  const exam = getExamConfig();

  const sectionId =
    progressState.sectionId || (exam && exam.sectionId) || null;
  const title = progressState.title || (exam && exam.sectionTitle) || null;

  if (!sectionId) {
    console.warn(
      "quiz-data.saveSessionProgress: No sectionId found. " +
        "Set progressState.sectionId or window.examConfig.sectionId."
    );
    return;
  }

  const payload = {
    sectionId,
    title,
    lastQuestionId: progressState.lastQuestionId ?? null,
    lastQuestionIndex:
      typeof progressState.lastQuestionIndex === "number"
        ? progressState.lastQuestionIndex
        : null,
    lastScreenIndex:
      typeof progressState.lastScreenIndex === "number"
        ? progressState.lastScreenIndex
        : null,
    timerHidden: !!progressState.timerHidden,
    questionCountHidden: !!progressState.questionCountHidden,
    reviewMode: !!progressState.reviewMode,
    answers: progressState.answers || {},
    updatedAt: serverTimestamp(),
    createdAt: serverTimestamp()
  };

  const ref = doc(db, "users", user.uid, "examSessions", sectionId);
  await setDoc(ref, payload, { merge: true });
  return ref.id;
}

async function loadSessionProgress(sectionId) {
  const user = await requireUser();
  const effectiveSectionId = sectionId || getDefaultSectionId();

  if (!effectiveSectionId) {
    throw new Error(
      "quiz-data.loadSessionProgress: No sectionId provided and none found in examConfig."
    );
  }

  const ref = doc(db, "users", user.uid, "examSessions", effectiveSectionId);
  const snap = await getDoc(ref);
  if (!snap.exists()) return null;
  return { id: snap.id, ...snap.data() };
}

async function clearSessionProgress(sectionId) {
  const user = await requireUser();
  const effectiveSectionId = sectionId || getDefaultSectionId();

  if (!effectiveSectionId) {
    console.warn(
      "quiz-data.clearSessionProgress: No sectionId provided and none found in examConfig."
    );
    return;
  }

  const ref = doc(db, "users", user.uid, "examSessions", effectiveSectionId);
  await deleteDoc(ref);
}

async function logReviewChanges(sectionId, changes) {
  const user = await requireUser();
  if (!Array.isArray(changes) || changes.length === 0) return;

  const effectiveSectionId = sectionId || getDefaultSectionId();
  if (!effectiveSectionId) {
    console.warn(
      "quiz-data.logReviewChanges: No sectionId provided and none found in examConfig."
    );
    return;
  }

  const batch = writeBatch(db);

  changes.forEach((change) => {
    const ref = doc(
      collection(
        db,
        "users",
        user.uid,
        "examSessions",
        effectiveSectionId,
        "reviewChanges"
      )
    );

    const payload = {
      questionId: change.questionId || null,
      subQuestionId: change.subQuestionId || null,
      oldAnswerIndex:
        typeof change.oldAnswerIndex === "number"
          ? change.oldAnswerIndex
          : null,
      newAnswerIndex:
        typeof change.newAnswerIndex === "number"
          ? change.newAnswerIndex
          : null,
      durationSeconds:
        typeof change.durationSeconds === "number"
          ? change.durationSeconds
          : null,
      changedAt: serverTimestamp()
    };

    batch.set(ref, payload);
  });

  await batch.commit();
}

// -----------------------------------
// 8. Export attempts (local + remote)
// -----------------------------------
async function exportAttempts() {
  const local = loadLocalAttempts();
  let remote = [];

  try {
    remote = await loadAllResultsForUser();
  } catch (e) {
    console.warn(
      "quiz-data.exportAttempts: could not load remote results, exporting local only",
      e
    );
  }

  const data = {
    generatedAt: new Date().toISOString(),
    localAttempts: local,
    remoteAttempts: remote
  };

  try {
    const json = JSON.stringify(data, null, 2);
    const blob = new Blob([json], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "dreamschool-attempts-export.json";
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  } catch (e) {
    console.warn("quiz-data.exportAttempts: failed to export", e);
  }
}

// -----------------------------------
// 9. Section stats / latest attempt
// -----------------------------------
function computeStatsFromAttemptList(list) {
  if (!Array.isArray(list) || list.length === 0) {
    return {
      count: 0,
      bestPercent: null,
      avgPercent: null,
      lastPercent: null,
      lastTakenAt: null
    };
  }

  const count = list.length;
  let bestPercent = null;
  let sumPercent = 0;
  let lastPercent = null;
  let lastTakenAt = null;

  list.forEach((r, idx) => {
    const p = typeof r.scorePercent === "number" ? r.scorePercent : null;
    if (p !== null) {
      if (bestPercent === null || p > bestPercent) bestPercent = p;
      sumPercent += p;
      if (idx === 0) lastPercent = p;
    }
    if (idx === 0 && r.timestamp) lastTakenAt = r.timestamp;
  });

  const avgPercent =
    bestPercent === null ? null : Math.round(sumPercent / count);

  return {
    count,
    bestPercent,
    avgPercent,
    lastPercent,
    lastTakenAt
  };
}

async function loadSectionStats(sectionId) {
  const effectiveSectionId = sectionId || getDefaultSectionId();
  if (!effectiveSectionId) {
    return {
      sectionId: null,
      source: "none",
      count: 0,
      bestPercent: null,
      avgPercent: null,
      lastPercent: null,
      lastTakenAt: null
    };
  }

  let remote = [];
  let remoteError = null;

  try {
    const user = await requireUser();
    const attemptsCol = collection(db, "users", user.uid, "examAttempts");
    const q = query(
      attemptsCol,
      where("sectionId", "==", effectiveSectionId),
      orderBy("createdAt", "desc")
    );
    const snap = await getDocs(q);
    remote = snap.docs.map((d) => d.data());
  } catch (e) {
    remoteError = e;
    dbg("loadSectionStats: remote fetch failed, will try local", e);
  }

  if (remote && remote.length > 0) {
    const stats = computeStatsFromAttemptList(remote);
    return {
      sectionId: effectiveSectionId,
      source: "remote",
      ...stats
    };
  }

  const local = loadLocalAttempts()
    .filter((a) => a.sectionId === effectiveSectionId)
    .sort((a, b) => {
      const ta = a.timestamp || "";
      const tb = b.timestamp || "";
      return ta < tb ? 1 : ta > tb ? -1 : 0;
    });

  const stats = computeStatsFromAttemptList(local);
  return {
    sectionId: effectiveSectionId,
    source: remoteError ? "local-offline" : "local",
    ...stats
  };
}

async function loadLatestAttemptForSection(sectionId) {
  const user = await requireUser();
  const effectiveSectionId = sectionId || getDefaultSectionId();
  if (!effectiveSectionId) throw new Error("No sectionId provided.");

  // Canonical
  try {
    const attemptsCol = collection(db, "users", user.uid, "attempts");
    const q1 = query(
      attemptsCol,
      where("sectionId", "==", effectiveSectionId),
      orderBy("createdAt", "desc"),
      limit(1)
    );
    const snap1 = await getDocs(q1);
    if (!snap1.empty) {
      const d = snap1.docs[0];
      return { id: d.id, ...d.data() };
    }
  } catch (e) {
    dbg("loadLatestAttemptForSection canonical failed", e);
  }

  // Legacy fallback
  const legacyCol = collection(db, "users", user.uid, "examAttempts");
  const q2 = query(
    legacyCol,
    where("sectionId", "==", effectiveSectionId),
    orderBy("createdAt", "desc"),
    limit(1)
  );
  const snap2 = await getDocs(q2);
  if (snap2.empty) return null;
  const d = snap2.docs[0];
  return { id: d.id, ...d.data() };
}

// -----------------------------------
// 10. Legacy: recordTestResult helper
// -----------------------------------
async function recordTestResult({
  score,
  total,
  durationSeconds = 0,
  category = "General",
  answers = []
} = {}) {
  if (typeof score !== "number" || typeof total !== "number") {
    throw new Error("recordTestResult: score and total must be numbers");
  }

  const scorePercent = total > 0 ? Math.round((score / total) * 100) : 0;

  const items = Array.isArray(answers)
    ? answers.map((a, idx) => {
        const chosen =
          typeof a.chosenIndex === "number"
            ? a.chosenIndex
            : typeof a.answer === "number"
            ? a.answer
            : null;
        const correctIndex =
          typeof a.correctIndex === "number" ? a.correctIndex : null;

        let correctFlag = false;
        if (typeof a.correct === "boolean") {
          correctFlag = a.correct;
        } else if (chosen !== null && correctIndex !== null) {
          correctFlag = chosen === correctIndex;
        }

        return {
          number: idx + 1,
          id: a.qid || "q" + (idx + 1),
          correctIndex,
          chosenIndex: chosen,
          correct: correctFlag
        };
      })
    : [];

  const summary = {
    attemptId: createAttemptId(),
    sectionId: category,
    title: category,
    generatedAt: new Date().toISOString(),
    totals: {
      answered: total,
      correct: score,
      total,
      timeSpentSec: durationSeconds,
      scorePercent
    },
    items,
    uiState: {
      timerHidden: false,
      reviewMode: false,
      lastQuestionIndex: items.length - 1
    }
  };

  return appendAttempt(summary);
}

// -----------------------------------
// 11. Public API
// -----------------------------------
window.quizData = {
  VERSION: "2.0.0",
  auth,
  db,
  requireUser,
  waitForAuthReady,

  // Finished attempts
  appendAttempt,
  getAttempt,
  listAttempts,
  getCurrentUserRole,
  canReadOtherUsersData,
  loadResultsForSection,
  loadAllResultsForUser,
  loadSectionStats,
  loadLatestAttemptForSection,

  // In-progress sessions
  saveSessionProgress,
  loadSessionProgress,
  clearSessionProgress,
  logReviewChanges,

  // Recorder helpers (backup / exports only)
  exportAttempts,
  getLocalAttempts: loadLocalAttempts,
  clearLocalAttempts,

  // Legacy helper
  recordTestResult
};
